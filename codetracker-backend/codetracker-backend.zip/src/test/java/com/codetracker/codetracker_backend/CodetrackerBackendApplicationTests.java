package com.codetracker.codetracker_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodetrackerBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
