package com.codetracker.codetracker_backend.entity;

public enum Role { USER, ADMIN }
