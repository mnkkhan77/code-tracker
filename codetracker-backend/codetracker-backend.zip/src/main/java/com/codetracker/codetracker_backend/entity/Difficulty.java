package com.codetracker.codetracker_backend.entity;

public enum Difficulty { EASY, MEDIUM, HARD }
