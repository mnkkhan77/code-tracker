package com.codetracker.codetracker_backend.controller.user;

import com.codetracker.codetracker_backend.entity.Attempt;
import com.codetracker.codetracker_backend.service.AttemptService;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/attempts")
public class AttemptController {

    private final AttemptService attemptService;
    public AttemptController(AttemptService attemptService) {
        this.attemptService = attemptService;
    }

    @GetMapping("/user/{userId}")
    public List<Attempt> getAttemptsByUser(@PathVariable UUID userId) {
        return attemptService.getAttemptsByUser(userId);
    }

    @GetMapping("/problem/{problemId}")
    public List<Attempt> getAttemptsByProblem(@PathVariable UUID problemId) {
        return attemptService.getAttemptsByProblem(problemId);
    }

    @PostMapping
    public Attempt createAttempt(@RequestBody Attempt attempt) {
        return attemptService.createAttempt(attempt);
    }
}
