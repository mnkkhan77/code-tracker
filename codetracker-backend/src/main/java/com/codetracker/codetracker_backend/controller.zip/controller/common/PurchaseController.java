package com.codetracker.codetracker_backend.controller.common;

import com.codetracker.codetracker_backend.entity.Purchase;
import com.codetracker.codetracker_backend.service.PurchaseService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/purchases")
public class PurchaseController {

    private final PurchaseService purchaseService;
    public PurchaseController(PurchaseService purchaseService) {
        this.purchaseService = purchaseService;
    }

    @GetMapping("/user/{userId}")
    public List<Purchase> getPurchasesByUser(@PathVariable UUID userId) {
        return purchaseService.getPurchasesByUser(userId);
    }

    @PostMapping
    public Purchase createPurchase(@RequestBody Purchase purchase) {
        return purchaseService.createPurchase(purchase);
    }
}
