console.log("Ads script loaded");
