import { Problem, User } from "@/types/api";
import axios from "axios";

const apiClient = axios.create({
  baseURL: "http://localhost:8080/api/admin", // Your Spring Boot admin endpoint URL
});

// Mock functions for admin operations
// Replace with actual API calls to your Spring Boot backend

let mockUsers: User[] = [];
let mockProblems: Problem[] = [];

export const getUsers = async (): Promise<User[]> => {
  console.log("Fetching all users (mock)");
  // const response = await apiClient.get<User[]>("/users");
  // return response.data;
  return Promise.resolve(mockUsers);
};

export const addUser = async (
  userData: Omit<User, "id" | "registrationDate" | "_creationTime">
): Promise<User> => {
  console.log("Adding user (mock)", userData);
  const newUser: User = {
    id: `mock-user-${Date.now()}`,
    _creationTime: Date.now(),
    registrationDate: new Date().toISOString(),
    status: "active",
    problemsSolved: 0,
    ...userData,
  };
  mockUsers.push(newUser);
  // const response = await apiClient.post<User>("/users", userData);
  // return response.data;
  return Promise.resolve(newUser);
};

export const updateUser = async (
  userId: string,
  updates: Partial<User>
): Promise<User | undefined> => {
  console.log(`Updating user ${userId} (mock)`, updates);
  const userIndex = mockUsers.findIndex((u) => u.id === userId);
  if (userIndex > -1) {
    mockUsers[userIndex] = { ...mockUsers[userIndex], ...updates };
    return Promise.resolve(mockUsers[userIndex]);
  }
  // const response = await apiClient.patch<User>(`/users/${userId}`, updates);
  // return response.data;
  return Promise.resolve(undefined);
};

export const deleteUser = async (userId: string): Promise<void> => {
  console.log(`Deleting user ${userId} (mock)`);
  mockUsers = mockUsers.filter((u) => u.id !== userId);
  // await apiClient.delete(`/users/${userId}`);
  return Promise.resolve();
};

export const addProblem = async (
  problemData: Partial<Problem>
): Promise<Problem> => {
  console.log("Adding problem (mock)", problemData);
  const newProblem: Problem = {
    id: `mock-problem-${Date.now()}`,
    _creationTime: Date.now(),
    title: problemData.title || "New Mock Problem",
    difficulty: problemData.difficulty || "easy",
    tags: problemData.tags || [],
    topicId: problemData.topicId || "mock-topic-id",
  };
  mockProblems.push(newProblem);
  // const response = await apiClient.post<Problem>("/problems", problemData);
  // return response.data;
  return Promise.resolve(newProblem);
};

export const updateProblem = async (
  problemId: string,
  updates: Partial<Problem>
): Promise<Problem | undefined> => {
  console.log(`Updating problem ${problemId} (mock)`, updates);
  const problemIndex = mockProblems.findIndex((p) => p.id === problemId);
  if (problemIndex > -1) {
    mockProblems[problemIndex] = { ...mockProblems[problemIndex], ...updates };
    return Promise.resolve(mockProblems[problemIndex]);
  }
  // const response = await apiClient.patch<Problem>(`/problems/${problemId}`, updates);
  // return response.data;
  return Promise.resolve(undefined);
};

export const deleteProblem = async (problemId: string): Promise<void> => {
  console.log(`Deleting problem ${problemId} (mock)`);
  mockProblems = mockProblems.filter((p) => p.id !== problemId);
  // await apiClient.delete(`/problems/${problemId}`);
  return Promise.resolve();
};

export type { Problem, User };
