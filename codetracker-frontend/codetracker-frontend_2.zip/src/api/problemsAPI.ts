import { Problem, Topic, UserProgress } from "@/types/api";
import axios from "axios";

const apiClient = axios.create({
  baseURL: "http://localhost:8080/api", // Your Spring Boot backend URL
});

export const problemsApi = {
  async getTopics(): Promise<Topic[]> {
    const response = await apiClient.get<Topic[]>("/topics");
    return response.data;
  },

  async getTopicBySlug(slug: string): Promise<Topic | null> {
    try {
      const response = await apiClient.get<Topic>(`/topics/slug/${slug}`);
      return response.data;
    } catch (error) {
      if (axios.isAxiosError(error) && error.response?.status === 404) {
        return null;
      }
      throw error;
    }
  },

  async getProblems(): Promise<Problem[]> {
    const response = await apiClient.get<Problem[]>("/problems");
    return response.data;
  },

  async getProblemsByTopic(topicId: string): Promise<Problem[]> {
    const response = await apiClient.get<Problem[]>(
      `/topics/${topicId}/problems`
    );
    return response.data;
  },

  async createProblem(
    problemData: Omit<Problem, "_id" | "_creationTime">
  ): Promise<Problem> {
    const response = await apiClient.post<Problem>("/problems", problemData);
    return response.data;
  },

  async updateProblem(
    problemId: string,
    updates: Partial<Problem>
  ): Promise<Problem> {
    const response = await apiClient.put<Problem>(
      `/problems/${problemId}`,
      updates
    );
    return response.data;
  },

  async deleteProblem(problemId: string): Promise<void> {
    await apiClient.delete(`/problems/${problemId}`);
  },

  async getUserProgress(userId: string): Promise<UserProgress[]> {
    const response = await apiClient.get<UserProgress[]>(
      `/users/${userId}/progress`
    );
    return response.data;
  },

  async getUpcomingReviews(userId: string): Promise<UserProgress[]> {
    const response = await apiClient.get<UserProgress[]>(
      `/users/${userId}/reviews/upcoming`
    );
    return response.data;
  },

  async updateProblemStatus(
    userId: string,
    problemId: string,
    status: "not_started" | "in_progress" | "completed"
  ): Promise<UserProgress> {
    const response = await apiClient.put<UserProgress>(
      `/users/${userId}/progress/${problemId}/status`,
      { status }
    );
    return response.data;
  },

  async updateProblemBestTime(
    userId: string,
    problemId: string,
    bestTime: number
  ): Promise<UserProgress> {
    const response = await apiClient.put<UserProgress>(
      `/users/${userId}/progress/${problemId}/best-time`,
      { bestTime }
    );
    return response.data;
  },
};
