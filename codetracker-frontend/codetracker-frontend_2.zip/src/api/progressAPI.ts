// progressAPI.ts
import apiClient from "./apiClient";
import {
  AddAttemptDto,
  CreateProgressDto,
  UpdateProgressDto,
  UserProgress,
} from "./types";

export const getUserProgress = async (
  userId: string
): Promise<UserProgress[]> => {
  const res = await apiClient.get<UserProgress[]>(`/progress/user/${userId}`);
  return res.data;
};

export const getProblemProgress = async (
  problemId: string
): Promise<UserProgress> => {
  const res = await apiClient.get<UserProgress>(
    `/progress/problem/${problemId}`
  );
  return res.data;
};

export const createProgress = async (
  data: CreateProgressDto
): Promise<UserProgress> => {
  const res = await apiClient.post<UserProgress>("/progress", data);
  return res.data;
};

export const updateProgress = async (
  id: string,
  updates: UpdateProgressDto
): Promise<UserProgress> => {
  const res = await apiClient.put<UserProgress>(`/progress/${id}`, updates);
  return res.data;
};

export const addAttempt = async (
  progressId: string,
  attempt: AddAttemptDto
): Promise<UserProgress> => {
  const res = await apiClient.post<UserProgress>(
    `/progress/${progressId}/attempt`,
    attempt
  );
  return res.data;
};

export const deleteProgress = async (id: string): Promise<void> => {
  await apiClient.delete(`/progress/${id}`);
};
