// src/api/authAPI.ts
import apiClient from "./apiClient";
import { ServerUser, serverUserToUserProfile } from "./types";

export const register = async (payload: {
  name: string;
  email: string;
  password: string;
  role?: string;
  bio?: string;
}) => {
  const res = await apiClient.post("/auth/register", payload);
  // server returns created user (ServerUser) usually without tokens
  return serverUserToUserProfile(res.data as ServerUser);
};

export const login = async (payload: { email: string; password: string }) => {
  const res = await apiClient.post("/auth/login", payload);
  // Expect { token: "..." } or { accessToken, refreshToken, user: {...} }
  const data = res.data;
  if (data.token) {
    localStorage.setItem("token", data.token);
    return {
      token: data.token,
      user: data.user ? serverUserToUserProfile(data.user) : undefined,
    };
  } else if (data.accessToken) {
    localStorage.setItem("token", data.accessToken);
    return {
      token: data.accessToken,
      refreshToken: data.refreshToken,
      user: data.user ? serverUserToUserProfile(data.user) : undefined,
    };
  }
  return data;
};

export const logout = async () => {
  localStorage.removeItem("token");
  try {
    await apiClient.post("/auth/logout");
  } catch (e) {
    // ignore
  }
};
