import { CreditTransaction, Resume } from "@/types/api";
import axios from "axios";

const apiClient = axios.create({
  baseURL: "http://localhost:8080/api", // Your Spring Boot backend URL
});

export const atsApi = {
  async getUserCredits(userId: string): Promise<number> {
    const response = await apiClient.get<{ credits: number }>(
      `/users/${userId}/credits`
    );
    return response.data.credits;
  },

  async getUserResumes(userId: string): Promise<Resume[]> {
    const response = await apiClient.get<Resume[]>(`/users/${userId}/resumes`);
    return response.data;
  },

  async purchaseCredits(
    userId: string,
    packageType: "small" | "medium" | "large"
  ): Promise<{ success: boolean; newCredits: number }> {
    const response = await apiClient.post(`/users/${userId}/credits/purchase`, {
      packageType,
    });
    return response.data;
  },

  async uploadResume(
    userId: string,
    file: File
  ): Promise<{ success: boolean; analysisResult?: any; error?: string }> {
    const formData = new FormData();
    formData.append("resume", file);
    const response = await apiClient.post(
      `/users/${userId}/resumes/upload`,
      formData,
      {
        headers: { "Content-Type": "multipart/form-data" },
      }
    );
    return response.data;
  },

  async addCredits(
    userId: string,
    amount: number,
    type: "usage" | "bonus",
    description: string
  ): Promise<CreditTransaction> {
    const response = await apiClient.post<CreditTransaction>(
      `/users/${userId}/credits/add`,
      { amount, type, description }
    );
    return response.data;
  },
};
