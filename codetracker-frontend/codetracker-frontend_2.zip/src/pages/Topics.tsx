import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import sampleData from "@/data/sampleData";
import { motion } from "framer-motion";
import { ArrowRight, BookOpen } from "lucide-react";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

function TopicsContent() {
  const [topics, setTopics] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulate loading and calculate stats for each topic from local JSON
    const topicsWithStats = sampleData.topics.map((topic) => {
      const topicProblems = sampleData.problems.filter(
        (p) => p.topicId === topic.id
      );
      const completed = 0; // Hardcoded for demo
      const inProgress = 0; // Hardcoded for demo
      const totalProblems = topicProblems.length;

      return {
        ...topic,
        totalProblems,
        completed,
        inProgress,
        notStarted: totalProblems,
        progressPercentage: 0, // Hardcoded for demo
      };
    });

    setTopics(topicsWithStats);
    setLoading(false);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <h1 className="text-2xl md:text-3xl font-bold tracking-tight mb-2">
          Problem Topics
        </h1>
        <p className="text-muted-foreground">
          Choose a topic to start practicing problems
        </p>
      </motion.div>

      {/* Topics Grid */}
      <motion.div
        className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.1 }}
      >
        {topics.map((topic, index) => (
          <motion.div
            key={topic.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 * index }}
            whileHover={{ y: -4, scale: 1.02 }}
          >
            <Link to={`/topics/${topic.slug}`}>
              <Card className="h-full hover:border-primary/50 transition-all duration-200 cursor-pointer group">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg group-hover:text-primary transition-colors">
                      {topic.name}
                    </CardTitle>
                    <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all" />
                  </div>
                  {topic.description && (
                    <p className="text-sm text-slate-600 dark:text-slate-400">
                      {topic.description}
                    </p>
                  )}
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Progress */}
                  <div>
                    <div className="flex justify-between text-sm mb-2 high-contrast-text">
                      <span>Progress</span>
                      <span>{topic.progressPercentage}%</span>
                    </div>
                    <Progress
                      value={topic.progressPercentage}
                      className="h-2"
                    />
                  </div>

                  {/* Stats */}
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="text-center p-2 bg-secondary rounded">
                      <p className="font-semibold text-primary">
                        {topic.completed}
                      </p>
                      <p className="text-gray-800 dark:text-gray-200">
                        Completed
                      </p>
                    </div>
                    <div className="text-center p-2 bg-secondary rounded">
                      <p className="font-semibold">{topic.totalProblems}</p>
                      <p className="text-slate-600 dark:text-slate-400">
                        Total
                      </p>
                    </div>
                  </div>

                  {/* Status Badges */}
                  <div className="flex flex-wrap gap-2">
                    {topic.inProgress > 0 && (
                      <Badge variant="secondary" className="text-xs">
                        {topic.inProgress} in progress
                      </Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            </Link>
          </motion.div>
        ))}
      </motion.div>

      {topics.length === 0 && (
        <motion.div
          className="text-center py-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <BookOpen className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <h3 className="text-lg font-medium mb-2">No topics available</h3>
          <p className="text-muted-foreground">
            Topics will appear here once they're added to the system.
          </p>
        </motion.div>
      )}
    </div>
  );
}

export default function Topics() {
  return <TopicsContent />;
}
