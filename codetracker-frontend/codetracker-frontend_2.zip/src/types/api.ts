// This file is the single source of truth for all API-related type definitions.

// --- From problemsApi ---
export interface Topic {
  id: string;
  name: string;
  slug: string;
  description?: string;
  _creationTime: number;
}

export interface Problem {
  id: string;
  title: string;
  difficulty: "easy" | "medium" | "hard";
  tags: string[];
  topicId: string;
  description?: string;
  externalUrls?: Array<{
    platform: string;
    url: string;
  }>;
  _creationTime: number;
}

export interface UserProgress {
  id: string;
  userId: string;
  problemId: string;
  status: "not_started" | "in_progress" | "completed";
  notes?: string;
  bestTime?: number;
  attempts: Array<{
    duration: number;
    timestamp: number;
  }>;
  lastAttemptDate?: number;
  nextReviewDate?: number;
  completedDate?: number;
  _creationTime: number;
}

// --- From userApi ---
export interface User {
  id: string;
  name: string;
  email: string;
  registrationDate: string;
  status: "active" | "inactive";
  problemsSolved: number;
  lastReminderSent?: number;
  emailReminders?: boolean;
  _creationTime: number;
}

// --- From atsApi ---
export interface Resume {
  id: string;
  userId: string;
  fileName: string;
  fileId: string;
  atsScore: number;
  analysisResult: string;
  detailedAnalysis?: {
    keywordMatches: string[];
    missingKeywords: string[];
    formatIssues: string[];
    strengths: string[];
    improvements: string[];
    sections: Array<{
      name: string;
      score: number;
      feedback: string;
    }>;
  };
  _creationTime: number;
}

export interface CreditTransaction {
  id: string;
  userId: string;
  amount: number;
  type: "purchase" | "usage" | "bonus";
  description: string;
  packageType?: "small" | "medium" | "large";
  _creationTime: number;
}
