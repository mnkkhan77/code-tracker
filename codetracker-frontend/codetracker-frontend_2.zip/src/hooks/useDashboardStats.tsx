import { getDashboardData } from "@/api/problemsAPI";
import { Problem, Topic, UserProgress } from "@/api/types";
import { useEffect, useMemo, useState } from "react";

export function useDashboardStats() {
  const [loading, setLoading] = useState(true);
  const [problems, setProblems] = useState<Problem[]>([]);
  const [rawTopics, setRawTopics] = useState<Topic[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const data = await getDashboardData();
      if (data) {
        setProblems(data.problems);
        setRawTopics(data.topics);
        setUserProgress(data.userProgress);
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  const userStats = useMemo(() => {
    if (loading) return null;
    const totalProblems = problems.length;
    const completed = userProgress.filter(
      (p) => p.status === "COMPLETED"
    ).length;

    const inProgress = userProgress.filter(
      (p) => p.status === "IN_PROGRESS"
    ).length;
    const notStarted = totalProblems - completed - inProgress;
    const progressPercentage =
      totalProblems > 0 ? Math.round((completed / totalProblems) * 100) : 0;
    const totalTimeSpent = userProgress.reduce((total, progress) => {
      return (
        total +
        progress.attempts.reduce((sum, attempt) => sum + attempt.duration, 0)
      );
    }, 0);

    return {
      totalProblems,
      completed,
      inProgress,
      notStarted,
      progressPercentage,
      totalTimeSpent,
    };
  }, [loading, problems, userProgress]);

  const upcomingReviews = useMemo(() => {
    if (loading || !userProgress || !problems || !rawTopics) return [];

    const now = Date.now();

    return userProgress
      .filter((progress) => {
        if (!progress.nextReviewDate) return false;
        const nextDate = new Date(progress.nextReviewDate).getTime();
        return !isNaN(nextDate) && nextDate <= now;
      })
      .map((progress) => {
        const problem = problems.find((p) => p.id === progress.problemId);
        const topic = problem
          ? rawTopics.find((t) => t.id === problem.topicId)
          : null;
        return {
          ...progress,
          problem,
          topic,
        };
      })
      .filter((item) => item.problem && item.topic);
  }, [loading, userProgress, problems, rawTopics]);

  const topics = useMemo(() => {
    if (loading) return [];
    return rawTopics.map((topic) => {
      const problemsInTopic = problems.filter((p) => p.topicId === topic.id);
      const completedInTopic = userProgress.filter((progress) => {
        const problem = problems.find((p) => p.id === progress.problemId);
        return (
          problem &&
          problem.topicId === topic.id &&
          progress.status === "COMPLETED"
        );
      }).length;
      const progressPercentage =
        problemsInTopic.length > 0
          ? Math.round((completedInTopic / problemsInTopic.length) * 100)
          : 0;
      return {
        ...topic,
        completed: completedInTopic,
        totalProblems: problemsInTopic.length,
        progressPercentage,
      };
    });
  }, [loading, rawTopics, problems, userProgress]);

  return {
    loading,
    userStats,
    upcomingReviews,
    topics,
  };
}
