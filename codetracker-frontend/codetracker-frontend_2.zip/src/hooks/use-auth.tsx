import React, { createContext, useContext, useEffect, useState } from "react";
import { toast } from "sonner";

interface AuthContextType {
  isAuthenticated: boolean;
  isAdmin: boolean;
  isLoading: boolean;
  user?: { name: string; initials: string };
  signIn: () => void;
  signOut: () => void;
  login: (username: string, password: string) => Promise<{ isAdmin: boolean }>;
  register: (name: string) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [user, setUser] = useState<
    { name: string; initials: string } | undefined
  >(undefined);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    try {
      const storedAuth = localStorage.getItem("auth");
      if (storedAuth) {
        const { isAuthenticated, isAdmin, user } = JSON.parse(storedAuth);
        if (isAuthenticated) {
          setIsAuthenticated(true);
          setIsAdmin(isAdmin);
          setUser(user);
        }
      }
    } catch (error) {
      console.error("Failed to parse auth from localStorage", error);
      localStorage.removeItem("auth");
    } finally {
      setIsLoading(false); // Set loading to false after checking
    }
  }, []);

  const login = async (
    username: string,
    password: string
  ): Promise<{ isAdmin: boolean }> => {
    // Mock authentication logic
    if (username === "user" && password === "user") {
      const authData = {
        isAuthenticated: true,
        isAdmin: false,
        user: { name: "Regular User", initials: "RU" },
      };
      localStorage.setItem("auth", JSON.stringify(authData));
      setIsAuthenticated(authData.isAuthenticated);
      setIsAdmin(authData.isAdmin);
      setUser(authData.user);
      return { isAdmin: false };
    } else if (username === "admin" && password === "admin") {
      const authData = {
        isAuthenticated: true,
        isAdmin: true,
        user: { name: "Admin User", initials: "AU" },
      };
      localStorage.setItem("auth", JSON.stringify(authData));
      setIsAuthenticated(authData.isAuthenticated);
      setIsAdmin(authData.isAdmin);
      setUser(authData.user);
      return { isAdmin: true };
    } else {
      throw new Error("Invalid username or password");
    }
  };

  const register = (name: string) => {
    const initials = name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase();
    const authData = {
      isAuthenticated: true,
      isAdmin: false,
      user: { name, initials },
    };
    localStorage.setItem("auth", JSON.stringify(authData));
    setIsAuthenticated(true);
    setIsAdmin(false);
    setUser(authData.user);
    toast.success(`Welcome, ${name}! Registration successful.`);
  };

  const signIn = () => {
    const authData = {
      isAuthenticated: true,
      isAdmin: false,
      user: { name: "Regular User", initials: "RU" },
    };
    localStorage.setItem("auth", JSON.stringify(authData));
    setIsAuthenticated(true);
    setUser({ name: "Regular User", initials: "RU" });
    toast.success("Successfully signed in!");
  };

  const signOut = () => {
    localStorage.removeItem("auth");
    setIsAuthenticated(false);
    setIsAdmin(false);
    setUser(undefined);
    toast.success("You have been logged out.", { duration: 2000 });
  };

  const value = {
    isAuthenticated,
    isAdmin,
    user,
    isLoading,
    signIn,
    signOut,
    login,
    register,
  };

  return React.createElement(AuthContext.Provider, { value }, children);
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
