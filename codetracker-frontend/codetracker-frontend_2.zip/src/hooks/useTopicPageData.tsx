import { Problem } from "@/api/adminAPI";
import {
  updateUserProblemBestTime as apiUpdateBestTime,
  updateUserProblemStatus as apiUpdateStatus,
  getTopicPageData,
  Topic,
} from "@/api/problemsAPI";
import { useAuth } from "@/hooks/use-auth";
import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { toast } from "sonner";
import { useProblemFilters } from "./useProblemFilters";

export function useTopicPageData() {
  const { slug } = useParams<{ slug: string }>();
  const { isAuthenticated, isAdmin } = useAuth();

  const [topic, setTopic] = useState<Topic | null>(null);
  const [problems, setProblems] = useState<Problem[]>([]);
  const [loading, setLoading] = useState(true);

  const {
    filteredProblems,
    statusFilter,
    setStatusFilter,
    difficultyFilter,
    setDifficultyFilter,
    tagFilter,
    setTagFilter,
    allTags,
  } = useProblemFilters(problems);

  const fetchData = useCallback(async () => {
    if (!slug) return;
    setLoading(true);
    try {
      const data = await getTopicPageData(slug);
      if (data) {
        setTopic(data.topic);
        setProblems(data.problems as Problem[]);
      } else {
        setTopic(null);
        setProblems([]);
      }
    } catch (error) {
      toast.error("Failed to load topic data.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [slug]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const updateProblemStatus = useCallback(
    async (
      problemId: string,
      newStatus: "not_started" | "in_progress" | "completed"
    ) => {
      if (!isAuthenticated || isAdmin) return;

      const originalProblems = problems;
      const newProblems = problems.map((p) =>
        p.id === problemId ? { ...p, status: newStatus } : p
      );
      setProblems(newProblems);

      try {
        await apiUpdateStatus(problemId, newStatus);
        toast.success("Status updated!");
      } catch (error) {
        toast.error("Failed to update status. Reverting changes.");
        setProblems(originalProblems);
      }
    },
    [isAuthenticated, isAdmin, problems]
  );

  const updateProblemBestTime = useCallback(
    async (problemId: string, newTime: number) => {
      if (!isAuthenticated || isAdmin) return;

      const originalProblems = problems;
      const newProblems = problems.map((p) =>
        p.id === problemId ? { ...p, bestTime: newTime } : p
      );
      setProblems(newProblems);

      try {
        await apiUpdateBestTime(problemId, newTime);
        toast.success("Best time updated!");
      } catch (error) {
        toast.error("Failed to update best time. Reverting changes.");
        setProblems(originalProblems);
      }
    },
    [isAuthenticated, isAdmin, problems]
  );

  return {
    topic,
    loading,
    filteredAndSortedProblems: filteredProblems,
    filters: {
      statusFilter,
      setStatusFilter,
      difficultyFilter,
      setDifficultyFilter,
      tagFilter,
      setTagFilter,
    },
    allTags,
    updateProblemStatus,
    updateProblemBestTime,
  };
}
