import { UserProfile, useUserData } from "@/contexts/UserDataContext";

export function useProfilePage() {
  const { profile, loading, updateProfile } = useUserData();

  return {
    profile,
    loading,
    updateProfile,
  };
}

export type { UserProfile };
