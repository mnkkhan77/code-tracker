import { getReminders } from "@/api/problemsAPI";
import { useEffect, useState } from "react";

// Define a more specific type for a reminder item
export interface ReminderItem {
  problemId: string;
  status: "completed" | "in_progress" | "not_started";
  nextReviewDate?: number;
  problem: {
    id: string;
    title: string;
    difficulty: "easy" | "medium" | "hard";
  } | null;
  topic: {
    id: string;
    name: string;
    slug: string;
  } | null;
}

export function useRemindersPage() {
  const [reminders, setReminders] = useState<ReminderItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const data = await getReminders();
      if (data) {
        setReminders(data as ReminderItem[]);
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  return {
    reminders,
    loading,
  };
}
