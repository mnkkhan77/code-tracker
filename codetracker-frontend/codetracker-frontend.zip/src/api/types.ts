// src/api/types.ts

/** Generic UUID string type */
export type UUID = string;

/** ISO 8601 datetime string, e.g. "2025-08-20T12:34:56" */
export type ISODateTime = string;

/* =========================
   Enums (match backend)
   ========================= */

export enum Role {
  USER = "USER",
  ADMIN = "ADMIN",
}

export enum Difficulty {
  EASY = "EASY",
  MEDIUM = "MEDIUM",
  HARD = "HARD",
}

export enum ProgressStatus {
  NOT_STARTED = "NOT_STARTED",
  IN_PROGRESS = "IN_PROGRESS",
  COMPLETED = "COMPLETED",
}

export enum ProductType {
  SUBSCRIPTION = "SUBSCRIPTION",
  RESUME_ANALYSIS = "RESUME_ANALYSIS",
  CREDITS = "CREDITS",
}

export enum PurchaseStatus {
  PENDING = "PENDING",
  COMPLETED = "COMPLETED",
  FAILED = "FAILED",
}

/* =========================
   Core Entities (match API)
   ========================= */

export interface UserProfile {
  _id: string;
  name: string;
  email: string;
  bio?: string;
  avatarUrl?: string;
  problemsSolved?: number;
  currentStreak?: number;
  totalSubmissions?: number;
  rank?: string;
  joinDate?: string;
}

export interface Topic {
  id: UUID;
  createdDate: ISODateTime;
  name: string;
  description?: string | null;
  slug: string;
  // If you later persist color, add: color?: string;
}

export interface ExternalUrl {
  platform: string; // e.g., "LeetCode", "GFG"
  url: string;
}

export interface Problem {
  id: UUID;
  createdDate: ISODateTime;
  updatedDate?: ISODateTime | null;
  title: string;
  description?: string | null;
  difficulty: Difficulty;
  topicId?: UUID | null; // nullable if topic removed (ON DELETE SET NULL)
  tags: string[];
  externalUrls: ExternalUrl[];
  createdBy?: UUID | null;

  /** Frontend convenience (derived): user's current status for this problem */
  userStatus?: ProgressStatus;
  /** Frontend convenience (derived): user's best time for this problem */
  userBestTime?: number | null;
}

export interface Attempt {
  id?: UUID;
  duration: number; // seconds
  attemptDate: ISODateTime; // when the attempt occurred
  successful: boolean;
}

export interface UserProgress {
  id: UUID;
  userId: UUID;
  problemId: UUID;
  status: ProgressStatus;
  notes?: string | null;
  bestTime?: number | null;
  lastAttemptDate?: ISODateTime | null;
  nextReviewDate?: ISODateTime | null;
  completedDate?: ISODateTime | null;
  attempts: Attempt[];
}

export interface Purchase {
  id: UUID;
  userId?: UUID | null;
  productType: ProductType;
  amount: number; // decimal in backend -> number here
  currency: string; // e.g., "USD", "INR"
  status: PurchaseStatus;
  paidAt?: ISODateTime | null;
  providerRef?: string | null;
}

/* =========================
   Auth DTOs
   ========================= */

export interface RegisterRequest {
  name: string;
  email: string;
  password: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface AuthResponse {
  accessToken: string;
  refreshToken: string;
  user: UserProfile;
}

/* =========================
   Problem DTOs
   ========================= */

export interface CreateProblemDto {
  title: string;
  description?: string;
  difficulty: Difficulty;
  topicId?: UUID | null;
  tags?: string[];
  externalUrls?: ExternalUrl[];
}

export interface UpdateProblemDto {
  title?: string;
  description?: string;
  difficulty?: Difficulty;
  topicId?: UUID | null;
  tags?: string[];
  externalUrls?: ExternalUrl[];
}

/* =========================
   Topic DTOs
   ========================= */

export interface CreateTopicDto {
  name: string;
  description?: string;
  slug: string;
  // createdDate is server-populated
}

export interface UpdateTopicDto {
  name?: string;
  description?: string;
  slug?: string;
}

/* =========================
   Progress DTOs
   ========================= */

export interface CreateProgressDto {
  userId: UUID;
  problemId: UUID;
  status?: ProgressStatus; // default NOT_STARTED server-side if omitted
  notes?: string;
  bestTime?: number | null;
  lastAttemptDate?: ISODateTime | null;
  nextReviewDate?: ISODateTime | null;
  completedDate?: ISODateTime | null;
  attempts?: Attempt[];
}

export interface UpdateProgressDto {
  status?: ProgressStatus;
  notes?: string | null;
  bestTime?: number | null;
  lastAttemptDate?: ISODateTime | null;
  nextReviewDate?: ISODateTime | null;
  completedDate?: ISODateTime | null;
}

export interface AddAttemptDto {
  duration: number;
  attemptDate: ISODateTime;
  successful: boolean;
}

/* =========================
   User/Profile DTOs
   ========================= */

export interface UpdateUserProfileRequest {
  name?: string;
  bio?: string | null;
  // email update could be separate, depending on backend policy
}

/* =========================
   ATS / Credits DTOs
   ========================= */

export interface CreditsResponse {
  credits: number;
}

export interface ResumeRecord {
  id: string;
  fileName: string;
  atsScore: number;
  analysisResult: string;
  uploadDate: number; // epoch ms (kept as number client-side)
}

export interface UploadResumeResponse {
  success: boolean;
  analysisResult?: {
    score: number;
    feedback: string;
    resume: ResumeRecord;
  };
  error?: string;
}

/* =========================
   Pagination Helpers
   ========================= */

export interface Page<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  size: number;
  number: number; // 0-based page index
}

/* =========================
   View Models (composed)
   ========================= */

export interface TopicPageData {
  topic: Topic;
  problems: Problem[]; // often enriched with userStatus/userBestTime
}
