import apiClient from "./apiClient";
import { Problem, User } from "./types";

// USERS
export const getUsers = async () => {
  const res = await apiClient.get<User[]>("/admin/users");
  return res.data;
};

export const addUser = async (user: Omit<User, "_id" | "registrationDate">) => {
  const res = await apiClient.post<User>("/admin/users", user);
  return res.data;
};

export const updateUser = async (userId: string, updates: Partial<User>) => {
  const res = await apiClient.put<User>(`/admin/users/${userId}`, updates);
  return res.data;
};

export const deleteUser = async (userId: string) => {
  const res = await apiClient.delete(`/admin/users/${userId}`);
  return res.data;
};

// PROBLEMS
export const getProblems = async () => {
  const res = await apiClient.get<Problem[]>("/admin/problems");
  return res.data;
};

export const addProblem = async (
  problem: Omit<Problem, "_id" | "createdDate">
) => {
  const res = await apiClient.post<Problem>("/admin/problems", problem);
  return res.data;
};

export const updateProblem = async (
  problemId: string,
  updates: Partial<Problem>
) => {
  const res = await apiClient.put<Problem>(
    `/admin/problems/${problemId}`,
    updates
  );
  return res.data;
};

export const deleteProblem = async (problemId: string) => {
  const res = await apiClient.delete(`/admin/problems/${problemId}`);
  return res.data;
};
