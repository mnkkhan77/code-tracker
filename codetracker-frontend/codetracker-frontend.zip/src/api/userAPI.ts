import apiClient from "./apiClient";
import { User } from "./types";

export const getUserProfile = async (): Promise<User> => {
  const res = await apiClient.get<User>("/user/profile");
  return res.data;
};

export const updateUserProfile = async (
  updates: Partial<User>
): Promise<User> => {
  const res = await apiClient.put<User>("/user/profile", updates);
  return res.data;
};
