import apiClient from "./apiClient";

export const getUserCredits = async () => {
  const res = await apiClient.get("/ats/credits");
  return res.data;
};

export const purchaseCredits = async (
  packageType: "small" | "medium" | "large"
) => {
  const res = await apiClient.post("/ats/purchase", { packageType });
  return res.data;
};

export const uploadResumeForAnalysis = async (file: File) => {
  const formData = new FormData();
  formData.append("resume", file);

  const res = await apiClient.post("/ats/upload", formData, {
    headers: { "Content-Type": "multipart/form-data" },
  });

  return res.data;
};

export const getUserResumes = async () => {
  const res = await apiClient.get("/ats/resumes");
  return res.data;
};
