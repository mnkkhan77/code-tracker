import apiClient from "./apiClient";
import { Problem, Topic, TopicPageData, UserProgress } from "./types";

export const getTopics = async () => {
  const res = await apiClient.get<Topic[]>("/problems/topics");
  return res.data;
};

export const getProblems = async () => {
  const res = await apiClient.get<Problem[]>("/problems");
  return res.data;
};

export const getUserProgress = async () => {
  const res = await apiClient.get<UserProgress[]>("/problems/user-progress");
  return res.data;
};

export const getDashboardData = async () => {
  const res = await apiClient.get("/dashboard");
  return res.data;
};

export const getTopicPageData = async (slug: string) => {
  const res = await apiClient.get<TopicPageData>(`/topics/${slug}`);
  return res.data;
};

export const getReminders = async () => {
  const res = await apiClient.get("/reminders");
  return res.data;
};

export const updateUserProblemStatus = async (
  problemId: string,
  newStatus: string
) => {
  const res = await apiClient.put(`/problems/${problemId}/status`, {
    status: newStatus,
  });
  return res.data;
};

export const updateUserProblemBestTime = async (
  problemId: string,
  newTime: number | null
) => {
  const res = await apiClient.put(`/problems/${problemId}/best-time`, {
    bestTime: newTime,
  });
  return res.data;
};
