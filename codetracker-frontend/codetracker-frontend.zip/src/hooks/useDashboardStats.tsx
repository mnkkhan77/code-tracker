import type { Problem, Topic, UserProgress } from "@/api/problemsAPI";
import { getDashboardData } from "@/api/problemsAPI";
import { useEffect, useMemo, useState } from "react";

export function useDashboardStats() {
  const [loading, setLoading] = useState(true);
  const [problems, setProblems] = useState<Problem[]>([]);
  const [rawTopics, setRawTopics] = useState<Topic[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      const data = await getDashboardData();
      if (data) {
        setProblems(data.problems);
        setRawTopics(data.topics);
        setUserProgress(data.userProgress);
      }
      setLoading(false);
    };
    fetchData();
  }, []);

  const userStats = useMemo(() => {
    if (loading) return null;
    const totalProblems = problems.length;
    const completed = userProgress.filter(
      (p) => p.status === "completed"
    ).length;
    const inProgress = userProgress.filter(
      (p) => p.status === "in_progress"
    ).length;
    const notStarted = totalProblems - completed - inProgress;
    const progressPercentage =
      totalProblems > 0 ? Math.round((completed / totalProblems) * 100) : 0;
    const totalTimeSpent = userProgress.reduce((total, progress) => {
      return (
        total +
        progress.attempts.reduce((sum, attempt) => sum + attempt.duration, 0)
      );
    }, 0);

    return {
      totalProblems,
      completed,
      inProgress,
      notStarted,
      progressPercentage,
      totalTimeSpent,
    };
  }, [loading, problems, userProgress]);

  const upcomingReviews = useMemo(() => {
    if (loading) return [];
    const now = Date.now();
    return userProgress
      .filter(
        (progress) => progress.nextReviewDate && progress.nextReviewDate <= now
      )
      .map((progress) => {
        const problem = problems.find((p) => p._id === progress.problemId);
        const topic = problem
          ? rawTopics.find((t) => t._id === problem.topicId)
          : null;
        return {
          ...progress,
          problem,
          topic,
        };
      })
      .filter((item) => item.problem && item.topic);
  }, [loading, userProgress, problems, rawTopics]);

  const topics = useMemo(() => {
    if (loading) return [];
    return rawTopics.map((topic) => {
      const problemsInTopic = problems.filter((p) => p.topicId === topic._id);
      const completedInTopic = userProgress.filter((progress) => {
        const problem = problems.find((p) => p._id === progress.problemId);
        return (
          problem &&
          problem.topicId === topic._id &&
          progress.status === "completed"
        );
      }).length;
      const progressPercentage =
        problemsInTopic.length > 0
          ? Math.round((completedInTopic / problemsInTopic.length) * 100)
          : 0;
      return {
        ...topic,
        completed: completedInTopic,
        totalProblems: problemsInTopic.length,
        progressPercentage,
      };
    });
  }, [loading, rawTopics, problems, userProgress]);

  return {
    loading,
    userStats,
    upcomingReviews,
    topics,
  };
}
