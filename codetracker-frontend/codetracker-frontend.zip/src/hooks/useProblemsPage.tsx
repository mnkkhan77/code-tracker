import {
  addProblem as apiAddProblem,
  deleteProblem as apiDeleteProblem,
  updateProblem as apiUpdateProblem,
  Problem,
} from "@/api/adminAPI";
import {
  updateUserProblemBestTime as apiUpdateBestTime,
  updateUserProblemStatus as apiUpdateStatus,
  getProblems,
} from "@/api/problemsAPI";
import { useAuth } from "@/hooks/use-auth";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useProblemFilters } from "./useProblemFilters";

export function useProblemsPage() {
  const { isAuthenticated, isAdmin } = useAuth();
  const [allProblems, setAllProblems] = useState<Problem[]>([]);
  const [userProgress, setUserProgress] = useState<
    {
      problemId: string;
      status: "not_started" | "in_progress" | "completed";
      bestTime?: number | null;
    }[]
  >([]);
  const [loading, setLoading] = useState(true);

  const problemsWithStatus = useMemo(() => {
    return allProblems.map((p) => ({
      ...p,
      status: p.status || "not_started",
    }));
  }, [allProblems]);

  const {
    filteredProblems: filteredPartialProblems,
    statusFilter,
    setStatusFilter,
    difficultyFilter,
    setDifficultyFilter,
    tagFilter,
    setTagFilter,
    allTags,
  } = useProblemFilters(problemsWithStatus);

  const filteredProblems = useMemo(() => {
    const filteredIdSet = new Set(filteredPartialProblems.map((p) => p._id));
    // Use problemsWithStatus as the source of truth for full objects with defaulted status
    return problemsWithStatus.filter((p) => filteredIdSet.has(p._id));
  }, [problemsWithStatus, filteredPartialProblems]);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      // Simplified: Only fetch problems from adminApi, as it now contains all needed fields.
      const problemsData = await getProblems();
      setAllProblems(problemsData || []);
    } catch (error) {
      toast.error("Failed to load problems data.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const updateProblemStatus = useCallback(
    async (
      problemId: string,
      newStatus: "not_started" | "in_progress" | "completed"
    ) => {
      if (!isAuthenticated || isAdmin) return;
      const originalProblems = [...allProblems];
      setAllProblems((currentProblems) =>
        currentProblems.map((p) =>
          p._id === problemId ? { ...p, status: newStatus } : p
        )
      );
      try {
        // Note: This still calls the separate problemsApi for updates, which might be intended.
        await apiUpdateStatus(problemId, newStatus);
        toast.success("Status updated!");
      } catch (error) {
        toast.error("Failed to update status. Reverting changes.");
        setAllProblems(originalProblems);
      }
    },
    [isAuthenticated, isAdmin, allProblems]
  );

  const updateProblemBestTime = useCallback(
    async (problemId: string, newTime: number) => {
      if (!isAuthenticated || isAdmin) return;
      const originalProblems = [...allProblems];
      setAllProblems((currentProblems) =>
        currentProblems.map((p) =>
          p._id === problemId ? { ...p, bestTime: newTime } : p
        )
      );
      try {
        // Note: This still calls the separate problemsApi for updates.
        await apiUpdateBestTime(problemId, newTime);
        toast.success("Best time updated!");
      } catch (error) {
        toast.error("Failed to update best time. Reverting changes.");
        setAllProblems(originalProblems);
      }
    },
    [isAuthenticated, isAdmin, allProblems]
  );

  const addProblem = useCallback(
    async (problemToAdd: Partial<Problem>) => {
      try {
        await apiAddProblem({
          title: problemToAdd.title || "New Problem",
          difficulty: problemToAdd.difficulty || "easy",
          tags: problemToAdd.tags || [],
          topicId: problemToAdd.topicId || "topic_1",
          topicName: problemToAdd.topicName || "General",
          status: "not_started",
        });
        await fetchData();
        toast.success("Problem added successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to add problem.");
        throw error;
      }
    },
    [fetchData]
  );

  const updateProblem = useCallback(
    async (problemId: string, problemToUpdate: Partial<Problem>) => {
      try {
        await apiUpdateProblem(problemId, problemToUpdate);
        await fetchData();
        toast.success("Problem updated successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to update problem.");
        throw error;
      }
    },
    [fetchData]
  );

  const deleteProblem = useCallback(
    async (problemId: string) => {
      try {
        await apiDeleteProblem(problemId);
        await fetchData();
        toast.success("Problem deleted successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to delete problem.");
      }
    },
    [fetchData]
  );

  return {
    filteredProblems,
    statusFilter,
    setStatusFilter,
    difficultyFilter,
    setDifficultyFilter,
    tagFilter,
    setTagFilter,
    allTags,
    loading: loading,
    updateProblemStatus: updateProblemStatus,
    onBestTimeChange: updateProblemBestTime,
    addProblem,
    updateProblem,
    deleteProblem,
  };
}
