import {
  updateUserProfile as apiUpdateUserProfile,
  getUserProfile,
} from "@/api/userAPI";
import { useAuth } from "@/hooks/use-auth";
import {
  createContext,
  ReactNode,
  useCallback,
  useContext,
  useEffect,
  useState,
} from "react";
import { toast } from "sonner";

export interface UserProfile {
  _id: string;
  name: string;
  email: string;
  bio?: string;
  avatarUrl?: string;
  problemsSolved?: number;
  currentStreak?: number;
  totalSubmissions?: number;
  rank?: string;
  joinDate?: string;
}

interface UserDataContextType {
  profile: UserProfile | null;
  loading: boolean;
  updateProfile: (updatedData: Partial<UserProfile>) => Promise<void>;
  refreshProfile: () => Promise<void>;
}

const UserDataContext = createContext<UserDataContextType | undefined>(
  undefined
);

export const UserDataProvider = ({ children }: { children: ReactNode }) => {
  const { isAuthenticated } = useAuth();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async () => {
    if (!isAuthenticated) {
      setProfile(null);
      setLoading(false);
      return;
    }
    setLoading(true);
    try {
      const userProfile = await getUserProfile();
      setProfile(userProfile);
    } catch (error) {
      console.error("Failed to fetch profile", error);
      toast.error("Could not load your profile data.");
    } finally {
      setLoading(false);
    }
  }, [isAuthenticated]);

  useEffect(() => {
    fetchProfile();
  }, [fetchProfile]);

  const updateProfile = async (updatedData: Partial<UserProfile>) => {
    if (!profile) return;

    setLoading(true);
    try {
      const updatedProfile = await apiUpdateUserProfile(updatedData);
      setProfile(updatedProfile);
      toast.success("Profile updated successfully!");
    } catch (error) {
      toast.error("Failed to update profile.");
      console.error(error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  return (
    <UserDataContext.Provider
      value={{ profile, loading, updateProfile, refreshProfile: fetchProfile }}
    >
      {children}
    </UserDataContext.Provider>
  );
};

export const useUserData = () => {
  const context = useContext(UserDataContext);
  if (context === undefined) {
    throw new Error("useUserData must be used within a UserDataProvider");
  }
  return context;
};
