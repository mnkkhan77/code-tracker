// src/api/remindersAPI.ts
import { Reminder } from "@/types/api";
import apiClient from "./apiClient";

/**
 * Raw axios wrappers for reminder endpoints.
 * These will throw if the backend does not implement the endpoints; the service layer will handle fallback.
 */

export const getRemindersForUser = async (
  userId?: string
): Promise<Reminder[]> => {
  if (userId) {
    const res = await apiClient.get<Reminder[]>(`/reminders/user/${userId}`);
    return res.data;
  }
  const res = await apiClient.get<Reminder[]>("/reminders");
  return res.data;
};

export const createReminderApi = async (
  payload: Partial<Reminder>
): Promise<Reminder> => {
  const res = await apiClient.post<Reminder>("/reminders", payload);
  return res.data;
};

export const updateReminderApi = async (
  id: string,
  payload: Partial<Reminder>
): Promise<Reminder> => {
  const res = await apiClient.put<Reminder>(`/reminders/${id}`, payload);
  return res.data;
};

export const deleteReminderApi = async (id: string): Promise<void> => {
  await apiClient.delete(`/reminders/${id}`);
};
