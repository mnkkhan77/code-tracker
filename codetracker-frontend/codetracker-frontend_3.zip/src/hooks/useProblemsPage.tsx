import { useAuth } from "@/hooks/use-auth";
import * as problemsService from "@/services/problemsService";
import * as progressService from "@/services/progressService";
import { Problem, UserProgress } from "@/types/api";
import { useCallback, useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { useProblemFilters } from "./useProblemFilters";

export function useProblemsPage() {
  const { user, isAdmin } = useAuth();
  const [allProblems, setAllProblems] = useState<Problem[]>([]);
  const [userProgress, setUserProgress] = useState<UserProgress[]>([]);
  const [loading, setLoading] = useState(true);

  const problemsWithStatus = useMemo(() => {
    if (!allProblems) return [];
    if (user && !isAdmin && userProgress) {
      return allProblems.map((problem) => {
        const progress = userProgress.find((p) => p.problemId === problem.id);
        return {
          ...problem,
          status: progress ? progress.status : ("not_started" as const),
          bestTime: progress ? progress.bestTime : null,
        };
      });
    }
    return allProblems.map((p) => ({
      ...p,
      status: "not_started" as const,
      bestTime: null,
    }));
  }, [allProblems, userProgress, user, isAdmin]);

  const {
    filteredProblems,
    statusFilter,
    setStatusFilter,
    difficultyFilter,
    setDifficultyFilter,
    tagFilter,
    setTagFilter,
    allTags,
  } = useProblemFilters(problemsWithStatus);

  const fetchData = useCallback(async () => {
    setLoading(true);
    try {
      const [problemsData, userProgressData] = await Promise.all([
        problemsService.getAllProblems(),
        user && !isAdmin
          ? progressService.getUserProgress()
          : Promise.resolve([]),
      ]);

      const processedProblems = (problemsData || []).map((p) => ({
        ...p,
        difficulty: p.difficulty.toLowerCase() as "easy" | "medium" | "hard",
      }));

      setAllProblems(processedProblems);
      setUserProgress(userProgressData || []);
    } catch (error) {
      toast.error("Failed to load problems data.");
      console.error(error);
    } finally {
      setLoading(false);
    }
  }, [user, isAdmin]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const updateProblemStatus = useCallback(
    async (
      problemId: string,
      newStatus: "not_started" | "in_progress" | "completed"
    ) => {
      if (!user || isAdmin) return;

      const originalProgress = [...userProgress];

      setUserProgress((currentProgress) => {
        const progressExists = currentProgress.some(
          (p) => p.problemId === problemId
        );
        if (progressExists) {
          return currentProgress.map((p) =>
            p.problemId === problemId ? { ...p, status: newStatus } : p
          );
        } else {
          const newEntry: UserProgress = {
            id: `new-progress-${Date.now()}`,
            userId: user.id,
            problemId,
            status: newStatus,
          };
          return [...currentProgress, newEntry];
        }
      });

      try {
        const progressToUpdate = originalProgress.find(
          (p) => p.problemId === problemId
        );
        if (progressToUpdate) {
          await progressService.updateProgress(progressToUpdate.id, {
            ...progressToUpdate,
            status: newStatus,
          });
        } else {
          await progressService.createProgress({
            userId: user.id,
            problemId,
            status: newStatus,
          });
        }
        toast.success("Status updated!");
        await fetchData();
      } catch (error) {
        toast.error("Failed to update status. Reverting changes.");
        setUserProgress(originalProgress);
      }
    },
    [user, isAdmin, userProgress, fetchData]
  );

  const updateProblemBestTime = useCallback(
    async (problemId: string, newTime: number) => {
      if (!user || isAdmin) return;

      const originalProgress = [...userProgress];

      setUserProgress((currentProgress) => {
        const progressExists = currentProgress.some(
          (p) => p.problemId === problemId
        );
        if (progressExists) {
          return currentProgress.map((p) =>
            p.problemId === problemId ? { ...p, bestTime: newTime } : p
          );
        } else {
          const newEntry: UserProgress = {
            id: `new-progress-${Date.now()}`,
            userId: user.id,
            problemId,
            status: "in_progress",
            bestTime: newTime,
          };
          return [...currentProgress, newEntry];
        }
      });

      try {
        const progressToUpdate = originalProgress.find(
          (p) => p.problemId === problemId
        );
        if (progressToUpdate) {
          await progressService.updateProgress(progressToUpdate.id, {
            ...progressToUpdate,
            bestTime: newTime,
          });
        } else {
          await progressService.createProgress({
            userId: user.id,
            problemId,
            status: "in_progress",
            bestTime: newTime,
          });
        }
        toast.success("Best time updated!");
        await fetchData();
      } catch (error) {
        toast.error("Failed to update best time. Reverting changes.");
        setUserProgress(originalProgress);
      }
    },
    [user, isAdmin, userProgress, fetchData]
  );

  const addProblem = useCallback(
    async (problemToAdd: Partial<Problem>) => {
      try {
        await problemsService.addProblem(problemToAdd);
        await fetchData();
        toast.success("Problem added successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to add problem.");
        throw error;
      }
    },
    [fetchData]
  );

  const updateProblem = useCallback(
    async (problemId: string, problemToUpdate: Partial<Problem>) => {
      try {
        await problemsService.updateProblem(problemId, problemToUpdate);
        await fetchData();
        toast.success("Problem updated successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to update problem.");
        throw error;
      }
    },
    [fetchData]
  );

  const deleteProblem = useCallback(
    async (problemId: string) => {
      try {
        await problemsService.deleteProblem(problemId);
        await fetchData();
        toast.success("Problem deleted successfully!");
      } catch (error) {
        toast.error((error as Error).message || "Failed to delete problem.");
      }
    },
    [fetchData]
  );

  return {
    filteredProblems,
    statusFilter,
    setStatusFilter,
    difficultyFilter,
    setDifficultyFilter,
    tagFilter,
    setTagFilter,
    allTags,
    loading: loading,
    updateProblemStatus: updateProblemStatus,
    updateProblemBestTime,
    addProblem,
    updateProblem,
    deleteProblem,
  };
}
