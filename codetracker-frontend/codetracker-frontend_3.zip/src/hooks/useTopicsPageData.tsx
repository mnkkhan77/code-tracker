// src/hooks/useTopicsPageData.ts
import * as progressService from "@/services/progressService"; // ← your backend logic
import { TopicWithStats } from "@/types/api";
import { useEffect, useState } from "react";
import { useAuth } from "./use-auth";

export function useTopicsPageData() {
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [topicsWithStats, setTopicsWithStats] = useState<TopicWithStats[]>([]);

  useEffect(() => {
    async function fetchData() {
      if (!user) return;
      setLoading(true);
      try {
        // Replace with your actual backend call
        const data: TopicWithStats[] = await progressService.getTopicsWithStats(
          user.id
        );

        setTopicsWithStats(data);
      } catch (error) {
        console.error("Failed to load topics", error);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, [user]);

  return {
    loading,
    topicsWithStats,
  };
}
