// src/types/api.ts
// Centralized API types

// --- Auth & User ---
export type UserRole = "USER" | "ADMIN";

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  bio?: string;
  createdAt?: string; // ISO
  updatedAt?: string; // ISO
  avatarUrl?: string;
  problemsSolved?: number;
  currentStreak?: number;
  totalSubmissions?: number;
  rank?: string | number;
}

export interface UserStatsDto {
  problemsSolved: number;
  currentStreak: number;
  totalSubmissions: number;
}

// --- Topics & Problems ---
export type Difficulty = "easy" | "medium" | "hard";
export type ProgressStatus = "not_started" | "in_progress" | "completed";

export interface Topic {
  id: string;
  name: string;
  slug: string;
  description?: string;
}

export interface Problem {
  status: string | undefined;
  externalUrls: any;
  bestTime: null;
  id: string;
  title: string;
  difficulty: Difficulty;
  tags: string[];
  topicId: string;
  topicName?: string;
  url?: string;
  createdAt?: string;
  updatedAt?: string;
}

// --- User Progress ---
export interface UserProgress {
  id: string;
  userId: string;
  problemId: string;
  status: ProgressStatus;
  bestTime?: number; // seconds
  nextReviewDate?: string; // ISO
  lastAttemptAt?: string; // ISO
}

export interface CreateProgressDto {
  userId: string;
  problemId: string;
  status?: ProgressStatus;
  bestTime?: number;
}

export interface UpdateProgressDto {
  status?: ProgressStatus;
  bestTime?: number;
  nextReviewDate?: string;
}

// --- Attempts ---
export interface Attempt {
  id: string;
  userId: string;
  problemId: string;
  duration?: number; // seconds (optional if backend doesn’t track)
  timestamp: number; // epoch millis
}

export interface AddAttemptDto {
  userId: string;
  problemId: string;
  duration?: number;
  timestamp?: number; // if omitted, backend can set now
}

// --- Purchases / Credits / ATS (optional) ---
export interface Purchase {
  id: string;
  userId: string;
  packageType: "small" | "medium" | "large";
  amount?: number;
  createdAt: string; // ISO
}

export interface CreditTransaction {
  id: string;
  userId: string;
  amount: number;
  type: "usage" | "bonus";
  description?: string;
  createdAt: string; // ISO
}

export interface Resume {
  id: string;
  fileName: string;
  uploadedAt: string; // ISO
}

export interface Reminder {
  id: string; // uuid
  userId?: string; // optional: tie to a user when available
  title: string;
  notes?: string;
  remindAt?: string; // ISO datetime string when reminder should trigger
  completed?: boolean;
  createdAt: string; // ISO
  updatedAt?: string; // ISO
}

export interface TopicWithStats extends Topic {
  completedProblems: number;
  totalProblems: number;
  progressPercentage: number;
}
